<?php
  	defined('BASEPATH') or exit('No se permite acceso directo'); 
?>
	
	<div class="logos"><h5>CTT Exp & Rentals</h5></div>
	<div class="menu_bar">
		<a href="#" class="bt_menu"><i class="fas fa-bars"></i></a>
	</div>
	<nav>
		<ul class="menu"></ul>
		<div class="sign-out"></div>
	</nav>
		

	<script src="<?= PATH_VIEWS .	'Menu/Menu.js?v=1.0.0.0' ?>"></script>