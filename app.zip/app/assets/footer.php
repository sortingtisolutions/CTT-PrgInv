<footer>
		<div class="copy"></div>
		<div class="logo"></div>
	</footer>

<div id="msgError" class="msgError reposo"></div>	

	<!-- Scripts -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
	<script src="<?= PATH_ASSETS . 'lib/js-cookie.js?v=1.0.0.0' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/moment/moment-with-locales.min.js?v=1.0.0.0' ?>"></script>
	
	
	
	<script src="<?= PATH_ASSETS . 'lib/daterangepicker/daterangepicker.js?v=1.0.0.0' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/forms/forms.js?v=1.0.0.0' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/sticky.js?v=1.0.0.0' ?>"></script>
	
	
</body>
</html>