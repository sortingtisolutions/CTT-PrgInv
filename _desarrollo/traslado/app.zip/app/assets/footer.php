
	<footer>
		<div class="copy"></div>
		<div class="logo"></div>
	</footer>


	<!-- Scripts -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
	<script src="<?= PATH_ASSETS . 'lib/js-cookie.js' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/moment/moment-with-locales.min.js' ?>"></script>
	
	
	
	<script src="<?= PATH_ASSETS . 'lib/dataTable/datatables.min.js' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/daterangepicker/daterangepicker.js' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/forms/forms.js' ?>"></script>
	<script src="<?= PATH_ASSETS . 'lib/easy-gantt.js' ?>"></script>

	
</body>
</html>